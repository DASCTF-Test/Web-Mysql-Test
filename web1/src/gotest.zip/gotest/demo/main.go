package main

import (
	_ "gotest/demo/routers"
	"github.com/astaxie/beego"
)

func main() {
	beego.Run()
}

