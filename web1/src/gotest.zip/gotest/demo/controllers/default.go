package controllers

import (
	"fmt"
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/orm"
	_ "github.com/go-sql-driver/mysql" // import your used driver
)

type MainController struct {
	beego.Controller
}

type User struct {
	Id       int
	Username string
}

////阻塞式的执行外部shell命令的函数,等待执行完毕并返回标准输出
//func exec_shell(s string) (string, error){
//	//函数返回一个*Cmd，用于使用给出的参数执行name指定的程序
//	cmd := exec.Command("/bin/bash", "-c", s)
//
//	//读取io.Writer类型的cmd.Stdout，再通过bytes.Buffer(缓冲byte类型的缓冲器)将byte类型转化为string类型(out.String():这是bytes类型提供的接口)
//	var out bytes.Buffer
//	cmd.Stdout = &out
//
//	//Run执行c包含的命令，并阻塞直到完成。  这里stdout被取出，cmd.Wait()无法正确获取stdin,stdout,stderr，则阻塞在那了
//	err := cmd.Run()
//
//	return out.String(), err
//}

func init() {
	// set default database
	err := orm.RegisterDataBase("default", "mysql", "test:123456@tcp(127.0.0.1:3306)/test?charset=utf8", 30)
	if err != nil {
		panic(err)
	}

	// register model
	orm.RegisterModel(new(User))
}

func (c *MainController) Get() {
	c.Data["Website"] = "beego.me"
	c.Data["Email"] = "astaxie@gmail.com"
	c.TplName = "index.tpl"
	id := c.GetString("id")
	o := orm.NewOrm()
	var users []User
	num, err := o.Raw("SELECT id, username FROM users WHERE id = " + id).QueryRows(&users)
	if err == nil {
		fmt.Println("user nums: ", num)
	}
	fmt.Println(users)

	//client := redis.NewClient(&redis.Options{
	//	Addr:     "localhost:6379",
	//	Password: "root", // no password set
	//	DB:       0,  // use default DB
	//})
	//err = client.Set("testKey", "HelloRedis", 0).Err()
	//if err != nil {
	//	panic(err)
	//}

	//val, err := client.Get("testKey").Result()
	//if err != nil {
	//	panic(err)
	//}

	//c.Data["Result"] = users[0].Username + " " + val
	c.Data["Result"] = users[0].Username
}
